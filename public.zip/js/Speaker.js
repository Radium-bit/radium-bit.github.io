console.log(`
这里是Radium的博客，源代码公开，但请不要盗图，多谢合作。

使用由FLY_Mc提供的fly_engine进行加速（来源：https://flymc.cc）

下面是一只可爱的翎羽~
`);

console.log(`
                                                                                                                                                      
                                                                                                                                                      
                                                                                                                                                      
                                                                                               LJ                                                     
                                                                                               LB:                                                    
                                                                                               ;BB                                                    
                                                                                               ;BBR                                                   
                                                                                               sBXB,                                                  
                                                                                               EQKQg                                                  
                                                          .rXgBBBQBBBQBQQOac;.                 BMPgB.                                                 
                                                       .LMBBgEHKaXSXSXSH6QBBBBBBD5r,           BRMJ7U                                                 
                                                     ;gBBZHSHSa5a2SUSU52U15S66gRBBBBBBgL:     .Bsp. B                                                 
                                                   rBBgHXX5aUa5SUSUS552525wwJ22SXHHKPDDgRBQK  sw,r  B.                                                
                            .1.                  :BBgSXaaSXUa5S5aUSUSU52SUUwUw2J1sJJJsJc2GRQJ.BKGgc,B.                                                
                             BEsJr.             6BQHSHaX5XSX5a5aSa5aUSUS252S2U2U12J1sLcJ6OXBPB6ZOBQB1                                                 
                              O. rUXL:        .BBpXSHaHSHSa5X5XUa5XUaU5Ua2SUU2512sLsHpQBBBMBgpBBBZ7                                                   
                               Q:  .;wH5r.   :BBXHXHXHaXSHSX5aSXUSUSUaUS5SU522JsL2EQMBBBBBBQQQ1:                                                      
                                HH:   .:sSUiJBQaXXKaXXHSXaXSaUaSSUS5S5SUU2U1JL1XMBBR PBQBQ;                                                           
                                 :KPr,.. .,1QgSKXKaKSHaXaXSSaaUa5XUSUaUS2wLs5gBBBBBB. RBQBs                                                           
                                   .L1aaU7ZBD5aSXaKXKSXSHSH5XSS5S5SU512JJJPRBQBMQMBB1sgMRPBQc                                                         
                                          BBKaSXSaUaUa5aaX5SSSU5US1wJ256gBBBBBQBQBRRMBGZMgEMBa                                                        
                                         ,BMgDRODEEPPSa2U121U121215HERBBBBBRMgROD6GZOOOGRQGERB7                                                       
                            XPcww2wUww2J7:sBQgOgOgDMDBRROEZGGDDDEDDQQBDODMRgEOZOGOGDODORDBODRBB.                                                      
                            :B,   ....  ;Ui:BBQDDOGZGOgRQRQRQRQMQRBBGDRQZcLaKSH5aSa5KHDJ.ZOXZOBB                                                      
                             ,E1:, . .:pB1 gBQQBQBMQgRggDggMRMgBQMBBgp2p;::7HHSXSHXUJSc: OPSUSHBD                                                     
                               :L1S2aUJ:  PBBgMMgRQBRRMRMDgODZZMMBspMXr,r;:7GHKXKXKX5s;;sQOXXS5MB7                                                    
                                         5BBRgEawOQBGgRMggDgggpBB: ,2rHGRHspHPXHHHaSpROZBBaXXHUQQB,                                                   
                                        XgZOP5sL5gBaHRa5DDGZ6HZBBQBEBgEPgR6XHXKXHSSOBEc7RgaSHa5QBQB                                                   
                                       EGrL5JrrSHRBa,i:::;wH5UQBcU1BBBBBQQpXaPHKHXUgKZQBBBpaXHSBBQBB                                                  
                                      R6rrJK;,sOHgBE,:wSr1ZXPagO  :QPaPGBBBE6PPKEgQQBBB5 gZSH5ZDSBBQB,                                                
                                     QS;;;gJ,;Z1XRRBUHGOEEPPKPZB  ZRDGaPPRvZBBBBRLOBpPQc,B5KaUOB  7gBBK                                               
                                   .BJ711BD,::rUBggBBXpPpKpKpPGB  L,.5BX i   :L:  ;wQgv:RBXXH2BQB    :Zr                                              
                                  rBDSL,1g...sBBQMRBBD5PP6KpPppB. ,7 :2: .        ,;ri  BBaHagBQBB.                                                   
                                  ,.    D. rBBBMQRQBBBDPpP6P6pZB:   .       . . .  ,.   Bg5SgBBRQBB:                                                  
                                     .,B.,EBQBMQRQQQ.OBBQgGGEEGBr                .     1BDXMQBBBRQQBr                                                 
                                     :B;sBBBBBBBBBB:.,BUsBBRQgMBBROPaL7:::,           7KBMMQBgHRBBBBB1                                                
                                     7ERQBBBBDsBBBM:::;r :UBBBBBQg2apODBB7SRaw7:   .rELiQBBBrS,;ggRBBBg                                               
                                    ,QBBBBBB5  BB L1:;::::67 rBBBZXJ5UaM: 7gp6RBBBOBg, UBBBs gMEBBBBBQBB:                                             
                                    .r:,  :BQB1.  ,R,;:rJBp    ,DgwaGRBQ ;BEPpKQBB. Bi,BBB;.,R  :;rLLJ1P:                                             
                                            rBBM.  g;:rMBE      HagKSPK .BRHGQBBBB  XBRBK:,::M                                                        
                                              rBBB :Gs6B      BBQRQgKDc:7QBBQBQBs1B  rBDs21JsB                                                        
                                                LBBRBXB;      BBBQQRgQBB rBQBQRg.:BB   BBQBpgB                                                        
                                                  LBBBJ     .BBpgBMMQBBBc URB6Kg.;BBR,  ;:7BQB                                                        
                                                    sBBR.  :BBBssURQMEpQB,.sc.OB srpw.2     ;.                                                        
                                                      JBBX:BBBBEpOgBBPKHBX QJ    M, B;g:                                                              
                                                        rQBMBQBBBQQRBBBBBBBB;c7  BcrBBB                                                               
                                                         BBBRMgRRQMQgBEEBBBB67QBBBBDQQBD                                                              
                                                      rQBBQRQQBBBBpUEQ. cBBQBBXaBQBsEB6B.                                                             
                                                    XBBBBQMMgGEBMBBOBi., ;BBBB. BBMBr;BBg                                                             
                                                    BBBMQQBPSSaPBQBB2 ::.URp1U::BBBGD :BB.                                                            
                                                    ;BBQgRMBRZp6RBQQ.:::,B7:c   5pBGgM:,MB                                                            
                                                    BMggQRMgBBBBQBB,,::.JBBQB.  Z1M6ZgBr  r                                                           
                                                  ;BQROGMBQMgDPQQB: :;:,Rs6BBBQBBPORZRQBBOX                                                           
                                                 cBBBRQQBgRQBpEHOB7 .:,rB  :7LBBBBBBRPpUBBB                                                           
                                                :BBBRRMgOgRQMBRDMBQB;  gQ .c   ;BQQBBHs25BBJ                                                          
                                               :BBMRQBBRQRMgBBBBBBBBBX,B:.,J   rM2XQQEUUUE6BM                                                         
                                             BBBBBRRRBRMgMMROGBw7BBBBBBX .,L   5QXSRJ25XS2RHGB:                                                       
                                            BBBQBBBMQRRMBQBDZQB  :ZBBBBBp.rL   6RaKQ52XSX26BJ5BJ                                                      
                                            cBQRggEBMQMRRBQBBB;,:,.;RBBBBBiB,  gOHXB62UXSU5BZwLBg                                                     
                                            7BBBKEppQBgPZEQBBJ.:;::. sBQBB UBUSD6aaBBg25U1RBwgSJBB                                                    
                                           JBBRMBQZggMMQDZZBQ.:;;;;: UK,:; PQgDpaSwBBH122BRp:GRsOBB.                                                  
                                         rBBBgRgBMHQBRMRBMQQ;,;;;;;:,QBEgMBBBQRZZppQB1waBpgOLsB  .:                                                   
                                        BBBBMMRQRgXgBBRRRBB1.;;;;;;:;BBQRBU   .rXQRBBpaPHBpKDBB1                                                      
                                       BBBBBBBQODDRgOgBQQBM.:;i;r;;.SBREggB7JKRMBDgDBEHJHgBBpXgB                                                      
                                      BBBBQMBBBBRQDRDDORQB::;i;r;;:,BB6OOOBBBBMRDgGOQQgBKOBBGM6gO.                                                    
                                     7BQBBs .;PBBBBQQRRgB2.:;;i;r;:;BQBQOEGQMGgOgDDGBZp6DgBDKPRMQBZ.                                                  
                                     BBBg  R2:   rpBBBBBB,:i;i;r;;.KBBEBOO6QRDDDDgGgQBQ6PPK6PpP6BwEBP.                                                
                                    BBBB,  BQQMU:    :1Q7,;;r;r;i::QB. BBZGBgOgOgOgOQBJBG6ZpZPZPQ7 rBBE                                               
                                   LBBBB  gBPpPRBBRSr .Z,;;r;i;;;,7Bp  ZBODBOgggDgOgQR JBEp6KREKKBBs iBBp                    J,                       
                                  :QBBBB .BK6pBBQGBBBwB,,,:,:,,,, DBJ  .BgMQDDgDRDgDQQ  EBOPPgBKPBrQB  JBB6                rB;                        
                                  B:DE7r BgZMBLBQB6: :D;rrr7vLwX6MBB:   cBBBDgggDRgRRB:  5BB6BpBDR.BBB:  HQBXs;           BB.                         
                                  LH:w: 7BgBB.  .    BQRQBBQBBBBBQBB      OBRgRgMgRgMBH   ,MBB ,BB:sQ6B6   QBBBB7       LQB                           
                                   :r   BBBL        OBHaGBRRRRgRRMBB      ZBgRRRgRDRRBB     :r  .BBLrDaMR:  KZPZBBr:  :BBB                            
                                        Er         OBPP5BQRDROgOggBG      BBMgMRQMMRQBB::rc       :5J;HJ7HBG,.agKBBBRXBBQ                             
                                                  BBHPa6BQMQMMQQRQB7     DBBMQRQRQRMgQQBRpB         :p:r2RDBQX :BOJSZBBB                              
                                                  BBPPRBBDRGRDRgRRBBJ    QBDgGgGgDgggDMBrK7          .Z;SBBBBBBGgJ1JUwUE1                             
                                                  rBBBw:XBRgggggDRMB6    GBgDggggggRDRBB.R             XrJBBBBBBBBgH2UpB2.                            
                                                  DBQ   gQMgRggDgRB;     BBgRggOggggggBR 7:             Ur:PQBBBBMBBR5BQgBB;                          
                                                 BQB.  EQMgggRggDQQ     rBRgDggggRDRDRRBs,B.             Ls:sSMBB6:7B  BBEDBg                         
                                                 BB;.,MBQDRDQRMDggBR    cBBgQgMgRMBBQQBBBLs.              iX:csss;irE7  rQBgBB;                       
                                                  BBDQBBBBBBBBBBMQBB:    BBMRQMQBQ,aQBBBB,                 ,P:717cLLrDH   .ZBBQg                      
                                                 sBBBBQMBQBE: ,BBBB:.   ,QQGgORDRBr r;   S.                  6ii2Lsvvr6M     LBBB;                    
                                                 BBQgMRBB7   ,cRgRBr    ;BRggggRgBBH  :7wQQ:                  Kc:2JJLLrUB:     :BBQ                   
                                          ...,:,.BBQRRB6   pBQBRRRBB7;7:EBMDRgMRRMBQBBBBBBBB ..                1X:r;r;r:rBs       QBU                 
                                 :rccssJJ112JJsJiKBBBBO  .BBQBBBQBBBLr7;MBBBBBBBBBBBQBBBBBBBrsJwJ1JJLL77:       r7:::,..            HE,               
                                 :7cJJ2J212JJsJLLiHpKZU2HDRKKSXSXaKXrr7;sOGZG6GEDEOEOGgGggQU7s1JU1211ssr:                             :               
                                               .       ...   . . ...,:::..                                                                            
`);